window.SARAH_SHOP_CONFIG = {
  storeName: "Sarah Shop",
  discordInvite: "https://discord.gg/rAQcaKJSF8"
};

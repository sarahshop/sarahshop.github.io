SARAH SHOP — WEBSITE

FILES
- index.html       Main storefront
- checkout.html    Order review + Discord Purchase Ticket
- success.html     Optional order-details handoff page
- tos.html         Terms of Service
- config.js        Store settings
- products.js      Products and prices
- sarah-banner.png Main banner
- sarah-logo.png   Store logo

PURCHASE FLOW
1. Buyer chooses a product/option on index.html.
2. Buyer reviews the order in checkout.html.
3. Buyer opens a Discord Purchase Ticket.
4. Staff confirms the exact item, price, payment details, and delivery.

IMPORTANT
- The website does not automatically take or verify crypto payments.
- Do not place wallet seed phrases, private keys, passwords, or other secrets in GitHub files.
- Current Discord invite: https://discord.gg/rAQcaKJSF8
